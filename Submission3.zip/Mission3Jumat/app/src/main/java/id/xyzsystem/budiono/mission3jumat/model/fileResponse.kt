package id.xyzsystem.budiono.mission3jumat.model

data class MatchResponse(val events: List<Match>)

data class MatchDetailResponse(val events: List<MatchDetail>)

data class TeamResponse(val teams: List<Team>)